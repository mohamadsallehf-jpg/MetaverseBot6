# 🎮 راهنمای نصب و اجرای ربات MetaverseBot

## 📋 پیش‌نیازها

- Python 3.9 یا بالاتر
- pip (مدیر پکیج Python)
- Git (اختیاری)
- Redis (اختیاری اما توصیه می‌شود)

---

## 🚀 نصب سریع

### 1. دانلود و استخراج
```bash
# اگر فایل zip دارید
unzip MetaverseBot.zip
cd MetaverseBot

# یا با git
git clone https://github.com/your-repo/MetaverseBot.git
cd MetaverseBot
```

### 2. ایجاد محیط مجازی (پیشنهادی)
```bash
python3 -m venv venv
source venv/bin/activate  # در Linux/Mac
# یا
venv\Scripts\activate  # در Windows
```

### 3. نصب Dependencies
```bash
# اجرای اسکریپت رفع باگ
python3 fix_bugs.py

# نصب پکیج‌ها
pip install -r requirements_fixed.txt
```

### 4. تنظیم فایل محیطی (env)
```bash
# کپی فایل نمونه
cp .env.example env

# ویرایش و تنظیم
nano env  # یا با هر ادیتور دیگر
```

**مهم**: این مقادیر را حتماً تنظیم کنید:
- `BOT_TOKEN`: توکن ربات از @BotFather
- `OWNER_IDS`: آیدی عددی شما
- `MAIN_GROUP_ID`: آیدی گروه اصلی
- `REQUIRED_CHANNEL`: آیدی کانال الزامی

### 5. راه‌اندازی ربات
```bash
# روش 1: استفاده از اسکریپت
./start_bot.sh

# روش 2: اجرای مستقیم
python3 main.py
```

---

## 🖥️ نصب در cPanel

### مرحله 1: آپلود فایل‌ها
1. وارد File Manager در cPanel شوید
2. دایرکتوری `public_html/bot` یا مسیر دلخواه ایجاد کنید
3. فایل zip را آپلود و استخراج کنید

### مرحله 2: دسترسی به Terminal
1. در cPanel بخش "Terminal" را باز کنید
2. به مسیر ربات بروید:
```bash
cd ~/public_html/bot
```

### مرحله 3: نصب Python Dependencies
```bash
# بررسی نسخه Python
python3 --version

# ایجاد محیط مجازی
python3 -m venv venv
source venv/bin/activate

# نصب پکیج‌ها
pip install -r requirements_fixed.txt
```

### مرحله 4: تنظیم و اجرا
```bash
# تنظیم فایل env
nano env

# اجرا در پس‌زمینه
nohup python3 main.py > bot.log 2>&1 &

# یا با screen
screen -S bot
python3 main.py
# Ctrl+A+D برای خروج
```

### مدیریت ربات در cPanel
```bash
# مشاهده لاگ
tail -f bot.log

# توقف ربات
./stop_bot.sh
# یا
pkill -f "python3 main.py"

# راه‌اندازی مجدد
./start_bot.sh
```

---

## 📱 نصب در Android (Termux)

### مرحله 1: نصب Termux
- دانلود از F-Droid (نه Google Play!)
- باز کردن Termux

### مرحله 2: نصب پیش‌نیازها
```bash
# به‌روزرسانی
pkg update && pkg upgrade

# نصب Python و Git
pkg install python git

# دسترسی به Storage
termux-setup-storage
```

### مرحله 3: دانلود و نصب ربات
```bash
# رفتن به downloads
cd ~/storage/downloads

# استخراج zip
unzip MetaverseBot.zip
cd MetaverseBot

# نصب dependencies
pip install -r requirements_fixed.txt
```

### مرحله 4: تنظیم و اجرا
```bash
# تنظیم env
nano env

# اجرا
python main.py
```

### نگه‌داشتن در پس‌زمینه
```bash
# نصب screen
pkg install screen

# اجرا در screen
screen -S bot
python main.py

# برای خروج: Ctrl+A+D
# برای بازگشت:
screen -r bot
```

---

## ⚙️ تنظیمات پیشرفته

### Redis (اختیاری)
```bash
# نصب Redis
# در Linux:
sudo apt install redis-server

# فعال‌سازی در env:
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
```

### PostgreSQL به جای SQLite
```env
# در فایل env:
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/dbname
```

### Monitoring با Sentry
```env
SENTRY_DSN=your_sentry_dsn_here
SENTRY_ENABLED=true
```

---

## 🔧 عیب‌یابی

### مشکل: ModuleNotFoundError
```bash
# حل:
pip install -r requirements_fixed.txt --force-reinstall
```

### مشکل: Permission Denied
```bash
# حل:
chmod +x *.sh
```

### مشکل: Redis Connection Failed
```bash
# حل: غیرفعال کردن Redis
# در env:
REDIS_ENABLED=false
```

### مشکل: Database Locked
```bash
# حل: بستن سایر نمونه‌های ربات
pkill -f "python3 main.py"
```

---

## 📝 دستورات مفید

```bash
# مشاهده وضعیت ربات
ps aux | grep main.py

# مشاهده لاگ زنده
tail -f logs/bot.log

# پشتیبان‌گیری از دیتابیس
cp metaverse_bot.db backups/backup_$(date +%Y%m%d).db

# بررسی فضای دیسک
du -sh .

# حذف فایل‌های موقت
rm -rf temp/*
rm -rf __pycache__
```

---

## 🆘 دریافت کمک

در صورت بروز مشکل:
1. ✅ لاگ‌ها را بررسی کنید: `logs/bot.log`
2. ✅ تنظیمات env را چک کنید
3. ✅ اطمینان از نصب صحیح dependencies
4. ✅ بررسی اتصال به اینترنت و Telegram

---

**موفق باشید! 🎉**
