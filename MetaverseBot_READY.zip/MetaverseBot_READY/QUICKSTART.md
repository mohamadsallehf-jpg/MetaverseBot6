# ⚡ Quick Start

Get your bot running in 5 minutes!

## 1. Clone & Setup

```bash
git clone https://github.com/yourusername/metaverse-bot.git
cd metaverse-bot
chmod +x setup.sh
./setup.sh
```

## 2. Configure

```bash
nano .env
```

Minimum required:
```env
BOT_TOKEN=your_token_from_botfather
MAIN_GROUP_ID=-1001234567890
REQUIRED_CHANNEL=@your_channel
OWNER_IDS=123456789
```

## 3. Run

```bash
source venv/bin/activate
python main.py
```

That's it! Bot is now running! 🎉

For detailed installation, see [INSTALL_VPS.md](INSTALL_VPS.md)
