# 🚀 شروع کنید اینجا!

## 🎉 تبریک! شما یک ربات متاورس حرفه‌ای دریافت کردید!

این ربات با بیش از **3,900 خط کد** و **20 فایل Python** ساخته شده و شامل:

✨ **ویژگی‌های کلیدی:**
- 🔐 سیستم امنیتی پیشرفته با Rate Limiting
- 💾 دیتابیس SQLAlchemy با PostgreSQL/SQLite
- 🔴 کش Redis برای عملکرد بهینه
- 🎮 سیستم بازی کامل با 35+ سلاح
- 💰 اقتصاد پیچیده با 4 ارز
- 💼 10 شغل مختلف با قابلیت‌های خاص
- 🏠 سیستم املاک و کارخانه
- 💎 سیستم VIP با 3 سطح
- 📊 آمار و تحلیل پیشرفته
- 🛡️ Anti-cheat و fraud detection
- 👮 پنل ادمین و مالک قدرتمند

---

## 📚 مستندات موجود

1. **[README.md](README.md)** - مستندات کامل ربات (14KB)
2. **[INSTALL_VPS.md](INSTALL_VPS.md)** - راهنمای گام‌به‌گام نصب روی VPS (11KB)
3. **[QUICKSTART.md](QUICKSTART.md)** - شروع سریع در 5 دقیقه
4. **[CHANGELOG.md](CHANGELOG.md)** - تغییرات نسخه
5. **[CONTRIBUTING.md](CONTRIBUTING.md)** - راهنمای مشارکت

---

## 🎯 سه راه برای شروع

### 🚀 راه 1: نصب سریع (5 دقیقه)

اگر فقط می‌خواهید ربات را اجرا کنید:

```bash
# 1. باز کردن پوشه
cd MetaverseBot

# 2. اجرای اسکریپت نصب
chmod +x setup.sh
./setup.sh

# 3. ویرایش تنظیمات
nano .env
# فقط این موارد الزامی است:
# BOT_TOKEN=...
# MAIN_GROUP_ID=...
# REQUIRED_CHANNEL=...
# OWNER_IDS=...

# 4. اجرا
source venv/bin/activate
python main.py
```

✅ [راهنمای کامل](QUICKSTART.md)

---

### 🖥️ راه 2: نصب روی VPS (راهنمای کامل)

اگر می‌خواهید ربات را روی سرور مجازی نصب کنید:

1. فایل `INSTALL_VPS.md` را باز کنید
2. دستورات را گام‌به‌گام دنبال کنید
3. شامل:
   - آماده‌سازی سرور
   - نصب PostgreSQL و Redis
   - تنظیمات امنیتی
   - اجرا با systemd
   - مانیتورینگ و بکاپ

✅ [راهنمای نصب VPS](INSTALL_VPS.md)

---

### 🐳 راه 3: اجرا با Docker (آسان‌ترین)

```bash
# با Docker Compose
docker-compose up -d

# یا با Docker معمولی
docker build -t metaverse-bot .
docker run -d --env-file .env metaverse-bot
```

---

## 📖 ساختار پروژه

```
MetaverseBot/
├── 📄 main.py                 # نقطه ورود اصلی
├── 📁 config/                 # تنظیمات (settings.py)
├── 📁 models/                 # مدل‌های دیتابیس
│   ├── user.py               # مدل کاربر (کامل‌ترین)
│   ├── transaction.py         # تراکنش‌ها
│   └── log.py                # لاگ‌ها
├── 📁 services/              # سرویس‌های تجاری
│   ├── cache.py              # Redis cache
│   └── user_service.py       # عملیات کاربر
├── 📁 handlers/              # دستورات ربات
│   ├── user_handlers.py      # دستورات کاربری
│   ├── economy_handlers.py   # اقتصاد
│   ├── game_handlers.py      # بازی‌ها
│   └── admin_handlers.py     # ادمین
├── 📁 middlewares/           # میدلورها
│   └── security.py           # امنیت و rate limit
└── 📁 utils/                 # توابع کمکی
```

---

## 🔑 تنظیمات ضروری

قبل از اجرا، **حتماً** این موارد را در `.env` تنظیم کنید:

### 1️⃣ توکن ربات
```env
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```
👉 از [@BotFather](https://t.me/BotFather) دریافت کنید

### 2️⃣ گروه اصلی
```env
MAIN_GROUP_ID=-1001234567890
```
👉 از [@userinfobot](https://t.me/userinfobot) دریافت کنید

### 3️⃣ کانال اجباری
```env
REQUIRED_CHANNEL=@your_channel
```
👉 با @ بنویسید و ربات را ادمین کانال کنید

### 4️⃣ آیدی مالک
```env
OWNER_IDS=123456789
```
👉 آیدی تلگرام خودتان

### 5️⃣ دیتابیس (اختیاری - به صورت پیش‌فرض SQLite)
```env
DATABASE_URL=sqlite+aiosqlite:///./metaverse_bot.db
```
👉 برای PostgreSQL از راهنمای VPS استفاده کنید

---

## ⚡ اجرای سریع بدون نصب

اگر فقط می‌خواهید تست کنید:

```bash
# نصب سریع وابستگی‌ها
pip install python-telegram-bot python-dotenv sqlalchemy aiosqlite loguru

# ویرایش .env
cp .env.example .env
nano .env

# اجرا
python main.py
```

⚠️ **توجه:** این روش فقط برای تست است. برای استفاده واقعی از virtual environment استفاده کنید.

---

## 🎮 دستورات اصلی ربات

بعد از اجرا، این دستورات را در گروه تلگرام تست کنید:

### برای کاربران:
```
/start      - شروع و ثبت‌نام
/help       - راهنما
/profile    - پروفایل
/coin       - سکه رایگان
/work       - کار کردن
/daily      - هدیه روزانه
/market     - بازار
/slot 1000  - بازی اسلات
```

### برای ادمین:
```
/admin      - پنل ادمین
/stats      - آمار
/ban        - بن کاربر
```

### برای مالک:
```
/owner      - پنل مالک
/backup     - بکاپ دیتابیس
```

---

## 🔧 چک‌لیست قبل از اجرا

- [ ] Python 3.9+ نصب شده
- [ ] فایل `.env` کپی و تنظیم شده
- [ ] توکن ربات وارد شده
- [ ] آیدی گروه وارد شده
- [ ] کانال اجباری تنظیم شده
- [ ] ربات در گروه و کانال ادمین شده
- [ ] وابستگی‌ها نصب شده (`pip install -r requirements.txt`)

---

## 🆘 مشکل دارید؟

### خطاهای رایج:

**1. `ModuleNotFoundError`**
```bash
pip install -r requirements.txt
```

**2. `Invalid token`**
- توکن را از BotFather مجدداً دریافت کنید
- بدون فاصله در .env کپی کنید

**3. `Chat not found`**
- آیدی گروه را چک کنید (باید با منفی شروع شود)
- ربات را ادمین گروه کنید

**4. ربات پاسخ نمی‌دهد**
- جوین کانال را چک کنید
- ربات باید ادمین کانال باشد

### راه‌های دریافت کمک:

1. 📖 ابتدا [README.md](README.md) را بخوانید
2. 📖 راهنمای [INSTALL_VPS.md](INSTALL_VPS.md) را مطالعه کنید
3. 🐛 در بخش Issues سوال بپرسید
4. 💬 در کانال پشتیبانی مطرح کنید

---

## 🎓 یادگیری بیشتر

### کدهای مهم برای مطالعه:

1. **`models/user.py`** - مدل کاربر با تمام ویژگی‌ها
2. **`middlewares/security.py`** - سیستم امنیتی و rate limiting
3. **`services/cache.py`** - سیستم کش Redis
4. **`handlers/`** - تمام دستورات ربات

### ویژگی‌های پیشرفته:

- ✅ Async/Await برای عملکرد بهتر
- ✅ Type Hints کامل
- ✅ Decorators برای کد تمیز
- ✅ Middleware Pattern
- ✅ Service Layer Architecture
- ✅ Comprehensive Logging
- ✅ Error Handling جامع

---

## 🚀 گام بعدی

بعد از راه‌اندازی موفق:

1. ✅ تست تمام دستورات
2. ✅ افزودن ادمین‌ها با `/addadmin`
3. ✅ تنظیم بکاپ خودکار
4. ✅ مانیتورینگ لاگ‌ها
5. ✅ سفارشی‌سازی (تغییر قیمت‌ها، cooldownها و...)

برای سفارشی‌سازی، فایل `config/settings.py` را ویرایش کنید.

---

## 📊 آمار پروژه

- 📝 **3,900+ خطوط کد Python**
- 📁 **20 فایل Python**
- 📚 **14KB مستندات**
- 🎮 **35+ سلاح**
- 💼 **10 شغل**
- 🎲 **6+ بازی**
- 🏠 **4 نوع خانه**
- 🏭 **4 نوع کارخانه**
- 💎 **3 سطح VIP**

---

## 💙 تشکر

از اینکه این ربات را انتخاب کردید متشکریم!

اگر سوالی دارید، در Issues بپرسید یا به کانال پشتیبانی بپیوندید.

**موفق و پیروز باشید!** 🎉

---

<div align="center">

**ساخته شده با ❤️ برای جامعه تلگرام**

[⭐ Star on GitHub](https://github.com/yourusername/metaverse-bot) | [📖 Documentation](README.md) | [🐛 Report Bug](https://github.com/yourusername/metaverse-bot/issues)

</div>
