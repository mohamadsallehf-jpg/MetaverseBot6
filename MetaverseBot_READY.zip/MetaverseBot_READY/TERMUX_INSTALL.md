# 📱 راهنمای نصب در Termux
## نصب گام به گام ربات متاورس در موبایل

---

## ⚠️ مهم: خطای Pydantic

اگر این خطا رو دیدید:
```
pydantic_settings.exceptions.SettingsError
```

**راه حل:**

### گام 1: حذف کامل و نصب مجدد Pydantic
```bash
pip uninstall pydantic pydantic-settings -y
pip install pydantic==2.5.3 pydantic-settings==2.1.0 --break-system-packages
```

### گام 2: بررسی فایل env
```bash
# باز کردن فایل
nano env

# مطمئن شوید این خطوط درست هستند:
BOT_TOKEN=توکن_ربات_شما
OWNER_IDS=123456789
ADMIN_IDS=123456789

# بدون فاصله، بدون علامت نقل قول!
```

---

## 🚀 نصب کامل در Termux

### مرحله 1: آماده‌سازی Termux

```bash
# دسترسی به حافظه
termux-setup-storage

# آپدیت پکیج‌ها
pkg update -y && pkg upgrade -y

# نصب ابزارهای پایه
pkg install python git unzip nano -y
```

### مرحله 2: آپلود فایل

**روش A: از Downloads**
```bash
cd ~/storage/downloads
ls
# پیدا کردن فایل ZIP

unzip MetaverseBot_ABSOLUTE_PERFECT_ZERO_BUGS.zip
cd MetaverseBot_ABSOLUTE_FINAL
```

**روش B: دانلود مستقیم** (اگر روی GitHub گذاشتید)
```bash
cd ~
git clone https://github.com/USERNAME/MetaverseBot.git
cd MetaverseBot
```

### مرحله 3: نصب Dependencies

```bash
# نصب پکیج‌های Python
pip install python-telegram-bot==20.7 --break-system-packages
pip install pydantic==2.5.3 --break-system-packages
pip install pydantic-settings==2.1.0 --break-system-packages
pip install loguru==0.7.2 --break-system-packages
pip install sqlalchemy==2.0.23 --break-system-packages
pip install aiosqlite==0.19.0 --break-system-packages
pip install python-dotenv==1.0.0 --break-system-packages
pip install greenlet==3.0.1 --break-system-packages
```

یا همه یکجا:
```bash
pip install -r requirements_production.txt --break-system-packages
```

### مرحله 4: تنظیم فایل env

```bash
# کپی فایل نمونه
cp env.example .env

# ویرایش
nano .env
```

**تنظیمات ضروری:**
```env
BOT_TOKEN=8267692992:AAHK0zp-Q0yo1jINasz03R7d212gmBvWBMI
BOT_USERNAME=Starswarsgamebot
MAIN_GROUP_ID=-1002438580956
REQUIRED_CHANNEL=@CodMmd_CH
OWNER_IDS=6580618549
ADMIN_IDS=6580618549
SECRET_KEY=my-secret-key-123
JWT_SECRET=my-jwt-secret-456
ENCRYPTION_KEY=my-encryption-789
```

**نکته:** توکن و آیدی‌های بالا فقط نمونه است - خودتون رو بذارید!

**ذخیره در nano:**
- `Ctrl + X`
- `Y`
- `Enter`

### مرحله 5: تست اجرا

```bash
# اجرای ربات
python3 main_FIXED.py
```

اگر این خطا آمد:
```
ModuleNotFoundError: No module named 'pydantic_settings'
```

**راه حل:**
```bash
pip install pydantic-settings==2.1.0 --break-system-packages
```

اگر این خطا آمد:
```
SettingsError: error parsing value
```

**راه حل:**
```bash
# بررسی فایل .env
cat .env | grep -E "(OWNER_IDS|ADMIN_IDS|BOT_TOKEN)"

# مطمئن شوید فرمت درسته:
# درست:   ADMIN_IDS=123456789
# غلط:    ADMIN_IDS="123456789"
# غلط:    ADMIN_IDS = 123456789
```

### مرحله 6: اجرای پس‌زمینه

```bash
# نصب termux-services
pkg install termux-services -y

# اجرا در پس‌زمینه
termux-wake-lock
nohup python3 main_FIXED.py > bot.log 2>&1 &

# دیدن لاگ
tail -f bot.log

# یا
cat bot.log
```

---

## 🔧 عیب‌یابی مشکلات رایج

### ❌ خطا 1: pydantic_settings not found
```bash
pip install pydantic-settings --break-system-packages
```

### ❌ خطا 2: SettingsError
```bash
# فایل env را بازبینی کنید
nano .env

# مطمئن شوید:
# - هیچ فاصله اضافی نباشد
# - هیچ علامت نقل قول نباشد
# - فرمت صحیح باشد: KEY=value
```

### ❌ خطا 3: Bot token invalid
```bash
# توکن جدید بگیرید از @BotFather
# /newbot بزنید
# توکن را در .env بگذارید
```

### ❌ خطا 4: Permission denied
```bash
chmod +x main_FIXED.py
python3 main_FIXED.py
```

### ❌ خطا 5: Database locked
```bash
# دیتابیس را حذف کنید
rm metaverse_bot.db
# دوباره اجرا کنید
python3 main_FIXED.py
```

---

## 📝 دستورات مفید

### دیدن لاگ:
```bash
tail -f bot.log
```

### متوقف کردن ربات:
```bash
pkill -f main_FIXED.py
```

### ریستارت ربات:
```bash
pkill -f main_FIXED.py
sleep 2
nohup python3 main_FIXED.py > bot.log 2>&1 &
```

### بررسی وضعیت:
```bash
ps aux | grep main_FIXED
```

### پاک کردن لاگ:
```bash
> bot.log
```

---

## ⚡ بهینه‌سازی برای Termux

### 1. جلوگیری از sleep شدن:
```bash
termux-wake-lock
```

### 2. ذخیره باتری:
```bash
# در فایل settings.py:
LOG_LEVEL=WARNING  # بجای INFO
REDIS_ENABLED=false
```

### 3. اجرای خودکار:
```bash
# نصب Termux:Boot
# ساخت اسکریپت استارت
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/start-bot.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
cd ~/MetaverseBot_ABSOLUTE_FINAL
python3 main_FIXED.py > bot.log 2>&1 &
EOF

chmod +x ~/.termux/boot/start-bot.sh
```

---

## ✅ چک‌لیست نهایی

قبل از اجرا مطمئن شوید:

- [ ] Python نصب شده: `python3 --version`
- [ ] همه پکیج‌ها نصب شده: `pip list | grep pydantic`
- [ ] فایل .env درست تنظیم شده: `cat .env`
- [ ] توکن ربات معتبر است
- [ ] ربات در گروه ادمین است
- [ ] ربات در کانال ادمین است
- [ ] آیدی‌ها صحیح هستند

---

## 🎯 تست سریع

```bash
# تست import
python3 -c "from config import settings; print('✅ Settings OK')"

# تست توکن
python3 -c "from config import settings; print(f'Token: {settings.BOT_TOKEN[:10]}...')"

# اجرای ربات
python3 main_FIXED.py
```

اگر همه چیز OK بود، باید این پیام رو ببینید:
```
🚀 Starting Metaverse Bot...
📊 Initializing database...
✅ Database initialized
🤖 Building bot application...
✅ Handlers registered
🎉 Bot initialization complete!
🤖 Bot is running...
```

---

## 🆘 کمک بیشتر

اگر مشکلی پیش اومد:
1. اسکرین‌شات خطا بگیرید
2. محتوای bot.log رو ببینید: `cat bot.log`
3. بررسی کنید توکن درسته
4. مطمئن شوید ربات ادمین گروه/کانال است

---

**موفق باشید!** 🚀

آخرین بروزرسانی: 2026-02-13
