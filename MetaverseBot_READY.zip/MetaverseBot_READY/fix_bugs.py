#!/usr/bin/env python3
"""
🔧 اسکریپت رفع خودکار باگ‌های ربات MetaverseBot
این اسکریپت تمام باگ‌های شناسایی شده را به صورت خودکار رفع می‌کند
"""

import os
import re
from pathlib import Path

print("🔧 شروع رفع باگ‌های ربات...")
print("=" * 60)

# 1. رفع باگ pydantic_settings در config/settings.py
print("\n1️⃣ رفع باگ pydantic_settings...")
settings_file = Path("config/settings.py")

if settings_file.exists():
    with open(settings_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # جایگزینی import
    old_import = "from pydantic_settings import BaseSettings"
    
    # چک کنیم pydantic-settings نصب هست یا نه
    try:
        import pydantic_settings
        print("   ✅ pydantic-settings نصب است - نیازی به تغییر نیست")
    except ImportError:
        print("   ⚠️ pydantic-settings نصب نیست - تغییر به pydantic")
        content = content.replace(
            "from pydantic_settings import BaseSettings",
            "from pydantic import BaseSettings"
        )
        
        with open(settings_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print("   ✅ Import اصلاح شد")
else:
    print("   ❌ فایل settings.py یافت نشد!")

# 2. رفع Type Hint در user.py
print("\n2️⃣ رفع Type Hint برای Python 3.9...")
user_file = Path("models/user.py")

if user_file.exists():
    with open(user_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # اضافه کردن import Tuple در صورت نیاز
    if "from typing import" in content and "Tuple" not in content:
        content = content.replace(
            "from typing import Optional, List, Dict, Any",
            "from typing import Optional, List, Dict, Any, Tuple"
        )
    
    # تبدیل tuple[...] به Tuple[...]
    content = re.sub(
        r'\) -> tuple\[([^\]]+)\]:',
        r') -> Tuple[\1]:',
        content
    )
    
    with open(user_file, 'w', encoding='utf-8') as f:
        f.write(content)
    print("   ✅ Type Hints اصلاح شد")
else:
    print("   ❌ فایل user.py یافت نشد!")

# 3. ایجاد requirements_fixed.txt
print("\n3️⃣ ایجاد فایل requirements بهبود یافته...")
requirements_content = """# Core Dependencies
python-telegram-bot==20.7
python-dotenv==1.0.0

# Pydantic
pydantic==2.5.3
pydantic-settings==2.1.0
email-validator==2.1.0

# Database
sqlalchemy==2.0.23
alembic==1.13.1
aiosqlite==0.19.0
asyncpg==0.29.0

# Redis for caching
redis==5.0.1
aioredis==2.0.1

# Security
cryptography==41.0.7
PyJWT==2.8.0
bcrypt==4.1.2
python-multipart==0.0.6

# Image Processing
Pillow==10.1.0
opencv-python-headless==4.8.1.78

# Charts and Analytics
matplotlib==3.8.2
pandas==2.1.4
plotly==5.18.0

# Rate Limiting
slowapi==0.1.9

# Monitoring and Logging
sentry-sdk==1.39.2
loguru==0.7.2

# HTTP Client
aiohttp==3.9.1
httpx==0.25.2

# Task Queue
celery==5.3.4

# Utils
pytz==2023.3
python-dateutil==2.8.2
humanize==4.9.0
shortuuid==1.0.11

# Testing (optional)
pytest==7.4.3
pytest-asyncio==0.21.1
pytest-cov==4.1.0

# Development (optional)
black==23.12.1
flake8==6.1.0
mypy==1.7.1
"""

with open("requirements_fixed.txt", 'w', encoding='utf-8') as f:
    f.write(requirements_content)
print("   ✅ فایل requirements_fixed.txt ایجاد شد")

# 4. ایجاد فایل .env نمونه در صورت نبودن
print("\n4️⃣ بررسی فایل .env...")
env_file = Path("env")
env_example = Path(".env.example")

if not env_file.exists():
    if env_example.exists():
        print("   📝 کپی .env.example به env")
        import shutil
        shutil.copy(env_example, env_file)
        print("   ⚠️ لطفاً فایل env را ویرایش و تنظیمات را وارد کنید!")
    else:
        print("   ⚠️ فایل .env.example یافت نشد - باید دستی ایجاد شود")
else:
    print("   ✅ فایل env موجود است")

# 5. ایجاد دایرکتوری‌های مورد نیاز
print("\n5️⃣ ایجاد دایرکتوری‌های مورد نیاز...")
directories = [
    "logs",
    "data",
    "backups",
    "assets",
    "temp"
]

for directory in directories:
    Path(directory).mkdir(exist_ok=True)
    print(f"   ✅ {directory}/")

# 6. ایجاد اسکریپت راه‌اندازی
print("\n6️⃣ ایجاد اسکریپت راه‌اندازی...")

# Start script
start_script = """#!/bin/bash
# 🚀 اسکریپت راه‌اندازی ربات MetaverseBot

echo "🤖 شروع ربات MetaverseBot..."
echo "================================"

# بررسی Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 نصب نیست!"
    exit 1
fi

# بررسی فایل env
if [ ! -f "env" ]; then
    echo "❌ فایل env یافت نشد!"
    echo "لطفاً فایل env را ایجاد و تنظیم کنید"
    exit 1
fi

# فعال‌سازی محیط مجازی در صورت وجود
if [ -d "venv" ]; then
    echo "📦 فعال‌سازی محیط مجازی..."
    source venv/bin/activate
fi

# نصب یا به‌روزرسانی dependencies
echo "📥 بررسی dependencies..."
if [ -f "requirements_fixed.txt" ]; then
    pip install -r requirements_fixed.txt --quiet
else
    pip install -r requirements.txt --quiet
fi

# اجرای ربات
echo "✅ اجرای ربات..."
python3 main.py

# در صورت خطا
if [ $? -ne 0 ]; then
    echo "❌ ربات با خطا متوقف شد!"
    echo "لاگ‌ها را در logs/bot.log بررسی کنید"
    exit 1
fi
"""

with open("start_bot.sh", 'w', encoding='utf-8') as f:
    f.write(start_script)

os.chmod("start_bot.sh", 0o755)
print("   ✅ start_bot.sh ایجاد شد")

# Stop script
stop_script = """#!/bin/bash
# 🛑 اسکریپت توقف ربات MetaverseBot

echo "🛑 توقف ربات MetaverseBot..."

# پیدا کردن process
PID=$(pgrep -f "python3 main.py")

if [ -z "$PID" ]; then
    echo "⚠️ ربات در حال اجرا نیست"
    exit 0
fi

# توقف process
kill $PID
echo "✅ ربات متوقف شد (PID: $PID)"

# صبر برای اطمینان
sleep 2

# بررسی مجدد
if pgrep -f "python3 main.py" > /dev/null; then
    echo "⚠️ ربات هنوز در حال اجراست - توقف اجباری..."
    pkill -9 -f "python3 main.py"
    echo "✅ ربات به طور اجباری متوقف شد"
fi
"""

with open("stop_bot.sh", 'w', encoding='utf-8') as f:
    f.write(stop_script)

os.chmod("stop_bot.sh", 0o755)
print("   ✅ stop_bot.sh ایجاد شد")

# 7. ایجاد فایل راهنما
print("\n7️⃣ ایجاد فایل راهنمای نصب...")

readme_fa = """# 🎮 راهنمای نصب و اجرای ربات MetaverseBot

## 📋 پیش‌نیازها

- Python 3.9 یا بالاتر
- pip (مدیر پکیج Python)
- Git (اختیاری)
- Redis (اختیاری اما توصیه می‌شود)

---

## 🚀 نصب سریع

### 1. دانلود و استخراج
```bash
# اگر فایل zip دارید
unzip MetaverseBot.zip
cd MetaverseBot

# یا با git
git clone https://github.com/your-repo/MetaverseBot.git
cd MetaverseBot
```

### 2. ایجاد محیط مجازی (پیشنهادی)
```bash
python3 -m venv venv
source venv/bin/activate  # در Linux/Mac
# یا
venv\\Scripts\\activate  # در Windows
```

### 3. نصب Dependencies
```bash
# اجرای اسکریپت رفع باگ
python3 fix_bugs.py

# نصب پکیج‌ها
pip install -r requirements_fixed.txt
```

### 4. تنظیم فایل محیطی (env)
```bash
# کپی فایل نمونه
cp .env.example env

# ویرایش و تنظیم
nano env  # یا با هر ادیتور دیگر
```

**مهم**: این مقادیر را حتماً تنظیم کنید:
- `BOT_TOKEN`: توکن ربات از @BotFather
- `OWNER_IDS`: آیدی عددی شما
- `MAIN_GROUP_ID`: آیدی گروه اصلی
- `REQUIRED_CHANNEL`: آیدی کانال الزامی

### 5. راه‌اندازی ربات
```bash
# روش 1: استفاده از اسکریپت
./start_bot.sh

# روش 2: اجرای مستقیم
python3 main.py
```

---

## 🖥️ نصب در cPanel

### مرحله 1: آپلود فایل‌ها
1. وارد File Manager در cPanel شوید
2. دایرکتوری `public_html/bot` یا مسیر دلخواه ایجاد کنید
3. فایل zip را آپلود و استخراج کنید

### مرحله 2: دسترسی به Terminal
1. در cPanel بخش "Terminal" را باز کنید
2. به مسیر ربات بروید:
```bash
cd ~/public_html/bot
```

### مرحله 3: نصب Python Dependencies
```bash
# بررسی نسخه Python
python3 --version

# ایجاد محیط مجازی
python3 -m venv venv
source venv/bin/activate

# نصب پکیج‌ها
pip install -r requirements_fixed.txt
```

### مرحله 4: تنظیم و اجرا
```bash
# تنظیم فایل env
nano env

# اجرا در پس‌زمینه
nohup python3 main.py > bot.log 2>&1 &

# یا با screen
screen -S bot
python3 main.py
# Ctrl+A+D برای خروج
```

### مدیریت ربات در cPanel
```bash
# مشاهده لاگ
tail -f bot.log

# توقف ربات
./stop_bot.sh
# یا
pkill -f "python3 main.py"

# راه‌اندازی مجدد
./start_bot.sh
```

---

## 📱 نصب در Android (Termux)

### مرحله 1: نصب Termux
- دانلود از F-Droid (نه Google Play!)
- باز کردن Termux

### مرحله 2: نصب پیش‌نیازها
```bash
# به‌روزرسانی
pkg update && pkg upgrade

# نصب Python و Git
pkg install python git

# دسترسی به Storage
termux-setup-storage
```

### مرحله 3: دانلود و نصب ربات
```bash
# رفتن به downloads
cd ~/storage/downloads

# استخراج zip
unzip MetaverseBot.zip
cd MetaverseBot

# نصب dependencies
pip install -r requirements_fixed.txt
```

### مرحله 4: تنظیم و اجرا
```bash
# تنظیم env
nano env

# اجرا
python main.py
```

### نگه‌داشتن در پس‌زمینه
```bash
# نصب screen
pkg install screen

# اجرا در screen
screen -S bot
python main.py

# برای خروج: Ctrl+A+D
# برای بازگشت:
screen -r bot
```

---

## ⚙️ تنظیمات پیشرفته

### Redis (اختیاری)
```bash
# نصب Redis
# در Linux:
sudo apt install redis-server

# فعال‌سازی در env:
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
```

### PostgreSQL به جای SQLite
```env
# در فایل env:
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/dbname
```

### Monitoring با Sentry
```env
SENTRY_DSN=your_sentry_dsn_here
SENTRY_ENABLED=true
```

---

## 🔧 عیب‌یابی

### مشکل: ModuleNotFoundError
```bash
# حل:
pip install -r requirements_fixed.txt --force-reinstall
```

### مشکل: Permission Denied
```bash
# حل:
chmod +x *.sh
```

### مشکل: Redis Connection Failed
```bash
# حل: غیرفعال کردن Redis
# در env:
REDIS_ENABLED=false
```

### مشکل: Database Locked
```bash
# حل: بستن سایر نمونه‌های ربات
pkill -f "python3 main.py"
```

---

## 📝 دستورات مفید

```bash
# مشاهده وضعیت ربات
ps aux | grep main.py

# مشاهده لاگ زنده
tail -f logs/bot.log

# پشتیبان‌گیری از دیتابیس
cp metaverse_bot.db backups/backup_$(date +%Y%m%d).db

# بررسی فضای دیسک
du -sh .

# حذف فایل‌های موقت
rm -rf temp/*
rm -rf __pycache__
```

---

## 🆘 دریافت کمک

در صورت بروز مشکل:
1. ✅ لاگ‌ها را بررسی کنید: `logs/bot.log`
2. ✅ تنظیمات env را چک کنید
3. ✅ اطمینان از نصب صحیح dependencies
4. ✅ بررسی اتصال به اینترنت و Telegram

---

**موفق باشید! 🎉**
"""

with open("INSTALL_FA.md", 'w', encoding='utf-8') as f:
    f.write(readme_fa)
print("   ✅ INSTALL_FA.md ایجاد شد")

# خلاصه نهایی
print("\n" + "=" * 60)
print("✅ رفع باگ‌ها تکمیل شد!")
print("=" * 60)
print("\n📋 خلاصه تغییرات:")
print("   1️⃣ رفع import pydantic_settings")
print("   2️⃣ رفع Type Hints")
print("   3️⃣ ایجاد requirements_fixed.txt")
print("   4️⃣ بررسی فایل env")
print("   5️⃣ ایجاد دایرکتوری‌ها")
print("   6️⃣ ایجاد اسکریپت‌های راه‌اندازی")
print("   7️⃣ ایجاد راهنمای نصب")

print("\n🚀 مراحل بعدی:")
print("   1. تنظیم فایل env")
print("   2. نصب dependencies: pip install -r requirements_fixed.txt")
print("   3. اجرای ربات: ./start_bot.sh یا python3 main.py")

print("\n📖 برای راهنمای کامل نصب فایل INSTALL_FA.md را مطالعه کنید")
print("\n✨ ربات آماده اجراست!")
