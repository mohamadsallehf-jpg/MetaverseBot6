"""
User command handlers
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from middlewares.security import require_group, require_channel, security
from config import settings, JobConfig
from models.base import db_manager
from services.user_service import UserService
from loguru import logger


@require_group
@require_channel
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start command - register user"""
    user_tg = update.effective_user
    user_id = user_tg.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get or create user
        user = await user_service.get_user(user_id)
        
        if not user:
            # Create new user
            user = await user_service.create_user(
                user_id=user_id,
                username=user_tg.username,
                first_name=user_tg.first_name,
                last_name=user_tg.last_name
            )
            await session.commit()
            
            welcome_text = f"""
🎮 <b>خوش آمدید به متاورس!</b>

سلام {user.first_name} عزیز! 👋

به دنیای متاورس خوش آمدی! اینجا می‌تونی:
💰 کار کنی و درآمد کسب کنی
🎮 بازی کنی و شرط‌بندی کنی  
🏠 خانه و املاک بخری
⚔️ سلاح بخری و بجنگی
💎 VIP شی و از امکانات ویژه استفاده کنی

💵 <b>موجودی اولیه:</b> {user.balance:,} تومان
📊 <b>سطح:</b> {user.level}
🆔 <b>کد معرف:</b> <code>{user.referral_code}</code>

برای راهنما: /help
برای مشاهده پروفایل: /profile
"""
        else:
            welcome_text = f"""
👋 <b>خوش برگشتی {user.first_name}!</b>

💰 <b>موجودی:</b> {user.balance:,} تومان
🏦 <b>بانک:</b> {user.bank:,} تومان
📊 <b>سطح:</b> {user.level}
💼 <b>شغل:</b> {user.job_info['name']}
{'⭐ <b>VIP</b>: فعال' if user.vip_active else ''}

برای شروع بازی: /help
"""
    
    keyboard = [
        [
            InlineKeyboardButton("💰 کار کردن", callback_data="work"),
            InlineKeyboardButton("🎮 بازی", callback_data="games")
        ],
        [
            InlineKeyboardButton("🏪 بازار", callback_data="market"),
            InlineKeyboardButton("📊 پروفایل", callback_data="profile")
        ],
        [
            InlineKeyboardButton("📈 رتبه‌بندی", callback_data="leaderboard"),
            InlineKeyboardButton("❓ راهنما", callback_data="help")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_text,
        parse_mode=ParseMode.HTML,
        reply_markup=reply_markup
    )


@require_group
@require_channel  
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Help command"""
    help_text = """
📚 <b>راهنمای کامل ربات</b>

<b>💰 دستورات اقتصادی:</b>
/coin - دریافت سکه رایگان (هر 5 دقیقه)
/work - کار کردن و کسب درآمد (هر 10 دقیقه)
/daily - هدیه روزانه (هر 24 ساعت)
/pay @username مقدار - انتقال سکه
/transfer مقدار - واریز به بانک
/withdraw مقدار - برداشت از بانک

<b>🎮 بازی‌ها:</b>
/bet مقدار - شرط‌بندی معمولی
/slot مقدار - ماشین اسلات
/dice مقدار - بازی تاس
/tas مقدار - همان dice

<b>🛒 خرید و فروش:</b>
/market - بازار اصلی
/guns - لیست سلاح‌ها
/buygun نام - خرید سلاح
/buyusd مقدار - خرید دلار
/sellusd مقدار - فروش دلار

<b>💼 شغل:</b>
/jobs - لیست مشاغل
/setjob نام - تغییر شغل

<b>📊 آمار:</b>
/info - اطلاعات حساب
/profile - پروفایل کامل
/top - برترین‌ها (سکه)
/toplevel - برترین‌ها (سطح)

<b>💎 VIP:</b>
/getvip - خرید VIP ({settings.VIP_PRICE:,} تومان)

<b>🎁 ویژگی‌های VIP:</b>
✅ ضریب کار 1.5x
✅ ضریب بازی 2x
✅ کولداون 50% کمتر
✅ شغل‌های ویژه
✅ بونس روزانه

برای هر سوال از /admin پشتیبانی بگیرید!
"""
    
    await update.message.reply_text(help_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def info_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Info command - brief account info"""
    user_id = update.effective_user.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text(
                "❌ شما ثبت‌نام نکرده‌اید! /start بزنید"
            )
            return
        
        vip_status = "✅ فعال" if user.vip_active else "❌ غیرفعال"
        
        info_text = f"""
👤 <b>اطلاعات حساب</b>

🆔 <b>شناسه:</b> <code>{user.user_id}</code>
📛 <b>نام:</b> {user.full_name}
{'👤 <b>یوزرنیم:</b> @' + user.username if user.username else ''}

💰 <b>موجودی:</b> {user.balance:,} تومان
🏦 <b>بانک:</b> {user.bank:,} تومان
💵 <b>دلار:</b> {user.usd} $
💎 <b>ثروت کل:</b> {user.total_wealth:,} تومان

📊 <b>سطح:</b> {user.level}
⭐ <b>XP:</b> {user.xp:,} / {user.xp_next:,}

💼 <b>شغل:</b> {user.job_info['name']}
💎 <b>VIP:</b> {vip_status}

🎮 <b>بازی‌ها:</b> {user.total_games}
🏆 <b>برد/باخت:</b> {user.wins}/{user.losses}
📊 <b>نرخ برد:</b> {user.win_rate:.1f}%

برای مشاهده پروفایل کامل: /profile
"""
        
        await update.message.reply_text(info_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Profile command - detailed profile"""
    user_id = update.effective_user.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text(
                "❌ شما ثبت‌نام نکرده‌اید! /start بزنید"
            )
            return
        
        # Get weapon name
        current_weapon_name = "ندارد"
        if user.current_weapon:
            from config import WeaponConfig
            weapon_data = WeaponConfig.WEAPONS.get(user.current_weapon)
            if weapon_data:
                current_weapon_name = weapon_data['name']
        
        vip_text = ""
        if user.vip_active:
            from datetime import datetime
            if user.vip_expire:
                days_left = (user.vip_expire - datetime.utcnow()).days
                vip_text = f"✅ فعال ({days_left} روز باقی‌مانده)"
            else:
                vip_text = "✅ فعال (نامحدود)"
        else:
            vip_text = "❌ غیرفعال"
        
        profile_text = f"""
👤 <b>پروفایل کامل</b>

━━━━━━━━━━━━━━━
<b>📋 اطلاعات پایه</b>
🆔 شناسه: <code>{user.user_id}</code>
📛 نام: {user.full_name}
{'👤 یوزرنیم: @' + user.username if user.username else ''}
🔐 کد محرمانه: <code>{user.secret_code}</code>
🎫 کد معرف: <code>{user.referral_code}</code>

━━━━━━━━━━━━━━━
<b>💰 اقتصادی</b>
💵 موجودی: {user.balance:,} تومان
🏦 بانک: {user.bank:,} تومان
💎 طلا: {user.gold}
💠 الماس: {user.diamond}
💵 دلار: {user.usd} $
⛏️ سنگ: {user.stone}
🪵 چوب: {user.wood}
💸 کل ثروت: {user.total_wealth:,} تومان

━━━━━━━━━━━━━━━
<b>📊 سطح و تجربه</b>
⭐ سطح: {user.level}
💫 XP: {user.xp:,} / {user.xp_next:,}
🎯 XP کل: {user.total_xp:,}

━━━━━━━━━━━━━━━
<b>💼 شغل</b>
👔 شغل فعلی: {user.job_info['name']}
📈 سطح شغلی: {user.job_level}
💪 تجربه شغلی: {user.job_experience}
💰 درآمد کار: ~{user.get_work_earnings():,} تومان

━━━━━━━━━━━━━━━
<b>🎮 آمار بازی</b>
🎯 کل بازی‌ها: {user.total_games}
🏆 برد: {user.wins}
💔 باخت: {user.losses}
📊 نرخ برد: {user.win_rate:.1f}%
🔥 Streak فعلی: {user.win_streak}
💥 بهترین Streak: {user.max_win_streak}

━━━━━━━━━━━━━━━
<b>💸 آمار مالی</b>
📈 کل درآمد: {user.total_earned:,}
📉 کل هزینه: {user.total_spent:,}
🎁 کل هدیه داده: {user.total_donated:,}
📥 کل دریافتی: {user.total_received:,}

━━━━━━━━━━━━━━━
<b>⚔️ سلاح</b>
🗡️ سلاح فعلی: {current_weapon_name}
📦 تعداد سلاح: {len(user.weapons) if user.weapons else 0}

━━━━━━━━━━━━━━━
<b>💎 VIP</b>
{vip_text}

━━━━━━━━━━━━━━━
<b>👥 ارجاع</b>
🎁 تعداد دعوت: {user.total_referrals}
💰 درآمد از ارجاع: {user.referral_earnings:,}

━━━━━━━━━━━━━━━
<b>🔥 فعالیت</b>
💼 تعداد کار: {user.total_work}
📱 کل دستورات: {user.total_commands}
🎮 آخرین فعالیت: {user.last_activity.strftime('%Y-%m-%d %H:%M') if user.last_activity else 'نامشخص'}
"""
        
        await update.message.reply_text(profile_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def jobs_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show available jobs"""
    jobs_text = "<b>💼 لیست مشاغل</b>\n\n"
    
    for job_id, job_data in JobConfig.JOBS.items():
        vip_badge = "💎" if job_data.get("vip_required") else ""
        level_req = job_data.get("required_level", 1)
        
        jobs_text += f"""
{job_data['name']} {vip_badge}
💰 درآمد پایه: {job_data['base_salary']:,} تومان
📊 سطح مورد نیاز: {level_req}
📝 {job_data['description']}

"""
    
    jobs_text += "\nبرای تغییر شغل: /setjob [نام شغل]"
    
    await update.message.reply_text(jobs_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def setjob_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set user job"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ لطفاً نام شغل را مشخص کنید!\n\n"
            "مثال: /setjob geda\n"
            "برای دیدن لیست مشاغل: /jobs"
        )
        return
    
    user_id = update.effective_user.id
    job_name = context.args[0].lower()
    
    if job_name not in JobConfig.JOBS:
        await update.message.reply_text(
            f"❌ شغل '{job_name}' یافت نشد!\n"
            "برای دیدن لیست مشاغل: /jobs"
        )
        return
    
    job_info = JobConfig.JOBS[job_name]
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check cooldown
        if not user.can_change_job():
            from datetime import datetime
            time_passed = datetime.utcnow() - user.last_job_change
            remaining = settings.COOLDOWN_JOB_CHANGE - time_passed.total_seconds()
            hours = int(remaining // 3600)
            minutes = int((remaining % 3600) // 60)
            
            await update.message.reply_text(
                f"⏰ شما به تازگی شغل خود را تغییر داده‌اید!\n"
                f"زمان باقی‌مانده: {hours} ساعت و {minutes} دقیقه"
            )
            return
        
        # Check level requirement
        if user.level < job_info['required_level']:
            await update.message.reply_text(
                f"❌ سطح شما کافی نیست!\n\n"
                f"📊 سطح شما: {user.level}\n"
                f"📊 سطح مورد نیاز: {job_info['required_level']}"
            )
            return
        
        # Check VIP requirement
        if job_info.get('vip_required', False) and not user.vip_active:
            await update.message.reply_text(
                f"❌ این شغل نیاز به VIP دارد!\n\n"
                f"برای خرید VIP: /getvip"
            )
            return
        
        # Change job
        old_job = user.job_info['name']
        user.job = job_name
        user.job_level = 1
        user.job_experience = 0
        user.last_job_change = datetime.utcnow()
        
        await session.commit()
        
        await update.message.reply_text(
            f"✅ شغل شما تغییر یافت!\n\n"
            f"📛 شغل قبلی: {old_job}\n"
            f"📛 شغل جدید: {job_info['name']}\n\n"
            f"💰 درآمد پایه: {job_info['base_salary']:,} تومان\n"
            f"📝 توضیحات: {job_info['description']}\n"
            f"🎯 توانایی ویژه: {job_info.get('special_ability', 'ندارد')}\n\n"
            f"⏰ تغییر بعدی: 24 ساعت دیگر"
        )


@require_group
@require_channel
async def leaderboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show leaderboard"""
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get top 10 users by balance
        top_users = await user_service.get_leaderboard(limit=10)
        
        if not top_users:
            await update.message.reply_text("📊 هنوز کاربری ثبت نشده است!")
            return
        
        leaderboard_text = "🏆 <b>برترین بازیکنان (ثروت)</b>\n\n"
        
        medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        
        for idx, user in enumerate(top_users):
            medal = medals[idx] if idx < len(medals) else f"{idx+1}."
            user_display = f"@{user.username}" if user.username else user.first_name
            wealth = user.total_wealth
            
            leaderboard_text += f"{medal} {user_display} - {wealth:,} تومان\n"
        
        # Find current user rank
        current_user_id = update.effective_user.id
        current_user = await user_service.get_user(current_user_id)
        
        if current_user:
            user_rank = await user_service.get_user_rank(current_user_id)
            leaderboard_text += f"\n━━━━━━━━━━━━━━━\n"
            leaderboard_text += f"📊 رتبه شما: #{user_rank}\n"
            leaderboard_text += f"💰 ثروت شما: {current_user.total_wealth:,} تومان"
        
        await update.message.reply_text(leaderboard_text, parse_mode=ParseMode.HTML)
