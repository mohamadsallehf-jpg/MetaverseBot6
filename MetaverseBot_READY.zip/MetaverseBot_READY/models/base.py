"""
Base models and database configuration
"""

from datetime import datetime
from typing import Any, Dict
from sqlalchemy import Column, Integer, BigInteger, String, Boolean, Float, DateTime, JSON, Text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import declarative_base, declared_attr
from sqlalchemy.pool import NullPool
from config import settings

# Base class
Base = declarative_base()


class TimestampMixin:
    """Mixin for created_at and updated_at timestamps"""
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class DatabaseManager:
    """Database manager with async support"""
    
    def __init__(self):
        self.engine = None
        self.session_factory = None
    
    async def init(self):
        """Initialize database engine and session factory"""
        self.engine = create_async_engine(
            settings.DATABASE_URL,
            echo=settings.DATABASE_ECHO,
            pool_size=settings.DATABASE_POOL_SIZE if 'sqlite' not in settings.DATABASE_URL else None,
            max_overflow=settings.DATABASE_MAX_OVERFLOW if 'sqlite' not in settings.DATABASE_URL else None,
            poolclass=NullPool if 'sqlite' in settings.DATABASE_URL else None,
            connect_args={"check_same_thread": False} if 'sqlite' in settings.DATABASE_URL else {}
        )
        
        self.session_factory = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Create all tables
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    
    async def get_session(self) -> AsyncSession:
        """Get database session"""
        async with self.session_factory() as session:
            yield session
    
    async def close(self):
        """Close database connections"""
        if self.engine:
            await self.engine.dispose()


# Global database manager instance
db_manager = DatabaseManager()
