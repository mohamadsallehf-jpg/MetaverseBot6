"""
Logging models for admin actions, security events, and user activities
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, BigInteger, String, Integer, DateTime, JSON, Text, Index, Enum as SQLEnum
from models.base import Base, TimestampMixin
import enum


class LogLevel(str, enum.Enum):
    """Log severity levels"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class LogCategory(str, enum.Enum):
    """Log categories"""
    USER_ACTION = "user_action"
    ADMIN_ACTION = "admin_action"
    SECURITY = "security"
    ECONOMY = "economy"
    GAME = "game"
    SYSTEM = "system"
    ERROR = "error"


class UserLog(Base, TimestampMixin):
    """User activity logs"""
    
    __tablename__ = "user_logs"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Log Details
    level = Column(SQLEnum(LogLevel), default=LogLevel.INFO, index=True)
    category = Column(SQLEnum(LogCategory), nullable=False, index=True)
    
    action = Column(String(100), nullable=False, index=True)
    description = Column(Text, nullable=True)
    
    # Additional Data
    metadata = Column(JSON, default=dict)
    
    # Context
    chat_id = Column(BigInteger, nullable=True)
    message_id = Column(BigInteger, nullable=True)
    
    # Security
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    logged_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_userlog_user_time', 'user_id', 'logged_at'),
        Index('idx_userlog_category', 'category', 'logged_at'),
    )


class AdminLog(Base, TimestampMixin):
    """Admin action logs"""
    
    __tablename__ = "admin_logs"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # Admin Info
    admin_id = Column(BigInteger, nullable=False, index=True)
    admin_username = Column(String(255), nullable=True)
    is_owner = Column(Boolean, default=False)
    
    # Action Details
    action = Column(String(100), nullable=False, index=True)
    description = Column(Text, nullable=True)
    
    # Target User (if applicable)
    target_user_id = Column(BigInteger, nullable=True, index=True)
    target_username = Column(String(255), nullable=True)
    
    # Before/After State
    state_before = Column(JSON, default=dict)
    state_after = Column(JSON, default=dict)
    
    # Additional Info
    reason = Column(Text, nullable=True)
    metadata = Column(JSON, default=dict)
    
    executed_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_adminlog_admin', 'admin_id', 'executed_at'),
        Index('idx_adminlog_target', 'target_user_id'),
    )


class SecurityEvent(Base, TimestampMixin):
    """Security events and violations"""
    
    __tablename__ = "security_events"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # Event Details
    event_type = Column(String(50), nullable=False, index=True)
    severity = Column(SQLEnum(LogLevel), default=LogLevel.WARNING, index=True)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Description
    description = Column(Text, nullable=False)
    metadata = Column(JSON, default=dict)
    
    # Action Taken
    action_taken = Column(String(100), nullable=True)
    auto_action = Column(Boolean, default=False)
    
    # Context
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    detected_at = Column(DateTime, default=datetime.utcnow, index=True)
    resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(BigInteger, nullable=True)
    
    __table_args__ = (
        Index('idx_security_user', 'user_id', 'detected_at'),
        Index('idx_security_type', 'event_type', 'severity'),
    )


class SystemLog(Base, TimestampMixin):
    """System-wide logs"""
    
    __tablename__ = "system_logs"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    level = Column(SQLEnum(LogLevel), default=LogLevel.INFO, index=True)
    category = Column(String(50), nullable=False, index=True)
    
    message = Column(Text, nullable=False)
    metadata = Column(JSON, default=dict)
    
    # Error tracking
    error_type = Column(String(100), nullable=True)
    error_trace = Column(Text, nullable=True)
    
    logged_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_syslog_level_time', 'level', 'logged_at'),
    )


class BanHistory(Base, TimestampMixin):
    """Ban history tracking"""
    
    __tablename__ = "ban_history"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Ban Details
    ban_type = Column(String(20), nullable=False)  # ban, mute, warn
    reason = Column(Text, nullable=False)
    duration = Column(Integer, nullable=True)  # seconds, None for permanent
    
    # Admin Info
    banned_by = Column(BigInteger, nullable=False)
    admin_username = Column(String(255), nullable=True)
    
    # Status
    is_active = Column(Boolean, default=True, index=True)
    
    banned_at = Column(DateTime, default=datetime.utcnow, index=True)
    expire_at = Column(DateTime, nullable=True)
    unbanned_at = Column(DateTime, nullable=True)
    unbanned_by = Column(BigInteger, nullable=True)
    
    __table_args__ = (
        Index('idx_ban_user', 'user_id', 'is_active'),
    )


class ChatMessage(Base, TimestampMixin):
    """Chat messages for analytics"""
    
    __tablename__ = "chat_messages"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # Message Info
    message_id = Column(BigInteger, nullable=False, index=True)
    chat_id = Column(BigInteger, nullable=False, index=True)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Content
    text = Column(Text, nullable=True)
    message_type = Column(String(50), nullable=True)  # text, photo, video, etc.
    
    # Metadata
    metadata = Column(JSON, default=dict)
    
    sent_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_message_chat_time', 'chat_id', 'sent_at'),
        Index('idx_message_user_time', 'user_id', 'sent_at'),
    )
