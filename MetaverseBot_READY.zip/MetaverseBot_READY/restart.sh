#!/bin/bash

# ═══════════════════════════════════════════════════════
# 🔄 MetaverseBot - Restart Script
# ═══════════════════════════════════════════════════════

GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}🔄 Restarting MetaverseBot...${NC}"
echo ""

./stop.sh
sleep 3
./start.sh

echo ""
echo -e "${GREEN}✅ Bot restarted${NC}"
