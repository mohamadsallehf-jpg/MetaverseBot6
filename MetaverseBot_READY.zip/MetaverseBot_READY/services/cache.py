"""
Redis cache service for high-performance caching
"""

import json
import pickle
from typing import Any, Optional, Union
from datetime import timedelta
import redis.asyncio as aioredis
from config import settings
from loguru import logger


class CacheService:
    """Redis cache service with advanced features"""
    
    def __init__(self):
        self.redis: Optional[aioredis.Redis] = None
        self._connected = False
    
    async def connect(self):
        """Connect to Redis"""
        if not settings.REDIS_ENABLED:
            logger.warning("Redis is disabled in settings")
            return
        
        try:
            self.redis = await aioredis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=False,
                max_connections=50
            )
            
            # Test connection
            await self.redis.ping()
            self._connected = True
            logger.success(f"✅ Connected to Redis at {settings.REDIS_HOST}:{settings.REDIS_PORT}")
        
        except Exception as e:
            logger.error(f"❌ Failed to connect to Redis: {e}")
            self._connected = False
    
    async def disconnect(self):
        """Disconnect from Redis"""
        if self.redis:
            await self.redis.close()
            self._connected = False
            logger.info("Redis connection closed")
    
    @property
    def is_connected(self) -> bool:
        """Check if Redis is connected"""
        return self._connected
    
    # ═══════════════════════════════════════════════════════
    # Basic Operations
    # ═══════════════════════════════════════════════════════
    
    async def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache"""
        if not self.is_connected:
            return default
        
        try:
            value = await self.redis.get(key)
            if value is None:
                return default
            
            # Try to deserialize
            try:
                return json.loads(value)
            except Exception as e:
                return pickle.loads(value)
        
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {e}")
            return default
    
    async def set(
        self, 
        key: str, 
        value: Any, 
        ttl: Optional[int] = None,
        serialize: str = "json"
    ) -> bool:
        """
        Set value in cache
        
        Args:
            key: Cache key
            value: Value to store
            ttl: Time to live in seconds (None for no expiry)
            serialize: Serialization method ('json' or 'pickle')
        """
        if not self.is_connected:
            return False
        
        try:
            # Serialize value
            if serialize == "json":
                serialized = json.dumps(value)
            else:
                serialized = pickle.dumps(value)
            
            # Set with or without TTL
            if ttl:
                await self.redis.setex(key, ttl, serialized)
            else:
                await self.redis.set(key, serialized)
            
            return True
        
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache"""
        if not self.is_connected:
            return False
        
        try:
            await self.redis.delete(key)
            return True
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists"""
        if not self.is_connected:
            return False
        
        try:
            return await self.redis.exists(key) > 0
        except Exception as e:
            return False
    
    async def expire(self, key: str, seconds: int) -> bool:
        """Set expiry on key"""
        if not self.is_connected:
            return False
        
        try:
            return await self.redis.expire(key, seconds)
        except Exception as e:
            return False
    
    async def ttl(self, key: str) -> int:
        """Get time to live for key"""
        if not self.is_connected:
            return -1
        
        try:
            return await self.redis.ttl(key)
        except Exception as e:
            return -1
    
    # ═══════════════════════════════════════════════════════
    # Advanced Operations
    # ═══════════════════════════════════════════════════════
    
    async def get_many(self, keys: list[str]) -> dict:
        """Get multiple keys at once"""
        if not self.is_connected:
            return {}
        
        try:
            values = await self.redis.mget(keys)
            result = {}
            
            for key, value in zip(keys, values):
                if value:
                    try:
                        result[key] = json.loads(value)
                    except Exception as e:
                        result[key] = pickle.loads(value)
            
            return result
        
        except Exception as e:
            logger.error(f"Cache get_many error: {e}")
            return {}
    
    async def set_many(self, mapping: dict, ttl: Optional[int] = None) -> bool:
        """Set multiple keys at once"""
        if not self.is_connected:
            return False
        
        try:
            pipe = self.redis.pipeline()
            
            for key, value in mapping.items():
                serialized = json.dumps(value)
                if ttl:
                    pipe.setex(key, ttl, serialized)
                else:
                    pipe.set(key, serialized)
            
            await pipe.execute()
            return True
        
        except Exception as e:
            logger.error(f"Cache set_many error: {e}")
            return False
    
    async def delete_many(self, keys: list[str]) -> bool:
        """Delete multiple keys at once"""
        if not self.is_connected:
            return False
        
        try:
            await self.redis.delete(*keys)
            return True
        except Exception as e:
            logger.error(f"Cache delete_many error: {e}")
            return False
    
    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching pattern"""
        if not self.is_connected:
            return 0
        
        try:
            keys = []
            async for key in self.redis.scan_iter(match=pattern):
                keys.append(key)
            
            if keys:
                return await self.redis.delete(*keys)
            return 0
        
        except Exception as e:
            logger.error(f"Cache delete_pattern error: {e}")
            return 0
    
    # ═══════════════════════════════════════════════════════
    # Counter Operations
    # ═══════════════════════════════════════════════════════
    
    async def incr(self, key: str, amount: int = 1) -> int:
        """Increment counter"""
        if not self.is_connected:
            return 0
        
        try:
            return await self.redis.incrby(key, amount)
        except Exception as e:
            return 0
    
    async def decr(self, key: str, amount: int = 1) -> int:
        """Decrement counter"""
        if not self.is_connected:
            return 0
        
        try:
            return await self.redis.decrby(key, amount)
        except Exception as e:
            return 0
    
    # ═══════════════════════════════════════════════════════
    # Hash Operations
    # ═══════════════════════════════════════════════════════
    
    async def hset(self, name: str, key: str, value: Any) -> bool:
        """Set hash field"""
        if not self.is_connected:
            return False
        
        try:
            serialized = json.dumps(value)
            await self.redis.hset(name, key, serialized)
            return True
        except Exception as e:
            logger.error(f"Cache hset error: {e}")
            return False
    
    async def hget(self, name: str, key: str, default: Any = None) -> Any:
        """Get hash field"""
        if not self.is_connected:
            return default
        
        try:
            value = await self.redis.hget(name, key)
            if value is None:
                return default
            return json.loads(value)
        except Exception as e:
            return default
    
    async def hgetall(self, name: str) -> dict:
        """Get all hash fields"""
        if not self.is_connected:
            return {}
        
        try:
            data = await self.redis.hgetall(name)
            result = {}
            for key, value in data.items():
                try:
                    result[key.decode()] = json.loads(value)
                except Exception as e:
                    result[key.decode()] = value
            return result
        except Exception as e:
            return {}
    
    async def hdel(self, name: str, *keys) -> int:
        """Delete hash fields"""
        if not self.is_connected:
            return 0
        
        try:
            return await self.redis.hdel(name, *keys)
        except Exception as e:
            return 0
    
    # ═══════════════════════════════════════════════════════
    # List Operations
    # ═══════════════════════════════════════════════════════
    
    async def lpush(self, key: str, *values) -> int:
        """Push to list (left)"""
        if not self.is_connected:
            return 0
        
        try:
            serialized = [json.dumps(v) for v in values]
            return await self.redis.lpush(key, *serialized)
        except Exception as e:
            return 0
    
    async def rpush(self, key: str, *values) -> int:
        """Push to list (right)"""
        if not self.is_connected:
            return 0
        
        try:
            serialized = [json.dumps(v) for v in values]
            return await self.redis.rpush(key, *serialized)
        except Exception as e:
            return 0
    
    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list:
        """Get range from list"""
        if not self.is_connected:
            return []
        
        try:
            values = await self.redis.lrange(key, start, end)
            return [json.loads(v) for v in values]
        except Exception as e:
            return []
    
    async def llen(self, key: str) -> int:
        """Get list length"""
        if not self.is_connected:
            return 0
        
        try:
            return await self.redis.llen(key)
        except Exception as e:
            return 0
    
    # ═══════════════════════════════════════════════════════
    # Set Operations
    # ═══════════════════════════════════════════════════════
    
    async def sadd(self, key: str, *values) -> int:
        """Add to set"""
        if not self.is_connected:
            return 0
        
        try:
            serialized = [json.dumps(v) for v in values]
            return await self.redis.sadd(key, *serialized)
        except Exception as e:
            return 0
    
    async def smembers(self, key: str) -> set:
        """Get all set members"""
        if not self.is_connected:
            return set()
        
        try:
            values = await self.redis.smembers(key)
            return {json.loads(v) for v in values}
        except Exception as e:
            return set()
    
    async def sismember(self, key: str, value: Any) -> bool:
        """Check if value in set"""
        if not self.is_connected:
            return False
        
        try:
            serialized = json.dumps(value)
            return await self.redis.sismember(key, serialized)
        except Exception as e:
            return False
    
    # ═══════════════════════════════════════════════════════
    # Special Game Functions
    # ═══════════════════════════════════════════════════════
    
    async def cache_user(self, user_id: int, data: dict, ttl: int = 300):
        """Cache user data"""
        key = f"user:{user_id}"
        await self.set(key, data, ttl)
    
    async def get_cached_user(self, user_id: int) -> Optional[dict]:
        """Get cached user data"""
        key = f"user:{user_id}"
        return await self.get(key)
    
    async def cache_leaderboard(self, board_type: str, data: list, ttl: int = 600):
        """Cache leaderboard"""
        key = f"leaderboard:{board_type}"
        await self.set(key, data, ttl)
    
    async def get_cached_leaderboard(self, board_type: str) -> Optional[list]:
        """Get cached leaderboard"""
        key = f"leaderboard:{board_type}"
        return await self.get(key)
    
    async def increment_rate_limit(self, user_id: int, action: str, window: int = 60) -> int:
        """Increment rate limit counter"""
        key = f"ratelimit:{action}:{user_id}"
        count = await self.incr(key)
        
        if count == 1:
            await self.expire(key, window)
        
        return count
    
    async def check_rate_limit(self, user_id: int, action: str, max_requests: int) -> tuple[bool, int]:
        """
        Check rate limit
        
        Returns:
            (is_limited, current_count)
        """
        key = f"ratelimit:{action}:{user_id}"
        count = await self.get(key, 0)
        
        if isinstance(count, str):
            count = int(count)
        
        return count >= max_requests, count
    
    async def clear_rate_limit(self, user_id: int, action: str):
        """Clear rate limit"""
        key = f"ratelimit:{action}:{user_id}"
        await self.delete(key)
    
    async def get_online_users(self) -> set:
        """Get set of online user IDs"""
        return await self.smembers("online_users")
    
    async def set_user_online(self, user_id: int, ttl: int = 300):
        """Mark user as online"""
        await self.sadd("online_users", user_id)
        await self.expire("online_users", ttl)
    
    async def flush_all(self):
        """Clear all cache (use with caution!)"""
        if not self.is_connected:
            return
        
        try:
            await self.redis.flushdb()
            logger.warning("⚠️ All cache cleared!")
        except Exception as e:
            logger.error(f"Cache flush error: {e}")


# Global cache instance
cache = CacheService()
