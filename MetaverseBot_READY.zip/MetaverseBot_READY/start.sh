#!/bin/bash

# ═══════════════════════════════════════════════════════
# 🚀 MetaverseBot - Start Script with Auto-Restart
# ═══════════════════════════════════════════════════════

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

BOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BOT_DIR"

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║    🎮 Starting MetaverseBot             ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# Check if already running
if pgrep -f "python.*main.py" > /dev/null; then
    echo -e "${YELLOW}⚠️  Bot is already running!${NC}"
    echo ""
    echo "Options:"
    echo "  1. Stop it first: ./stop.sh"
    echo "  2. View logs: tail -f logs/bot.log"
    echo "  3. Restart: ./restart.sh"
    exit 1
fi

# Check virtual environment
if [ ! -d "venv" ]; then
    echo -e "${RED}❌ Virtual environment not found!${NC}"
    echo -e "${CYAN}Run setup first: ./setup.sh${NC}"
    exit 1
fi

# Check config file
if [ ! -f "env" ]; then
    echo -e "${RED}❌ Configuration file 'env' not found!${NC}"
    echo -e "${CYAN}Create it from: cp env.example env${NC}"
    exit 1
fi

# Check if BOT_TOKEN is set
if grep -q "YOUR_BOT_TOKEN_HERE" env 2>/dev/null; then
    echo -e "${RED}❌ BOT_TOKEN not configured!${NC}"
    echo -e "${CYAN}Edit: nano env${NC}"
    exit 1
fi

echo -e "${CYAN}➜ Activating virtual environment...${NC}"
source venv/bin/activate

echo -e "${CYAN}➜ Starting bot with auto-restart...${NC}"
echo -e "${GREEN}✅ Bot started in background${NC}"
echo ""
echo "Useful commands:"
echo "  • View logs:    tail -f logs/bot.log"
echo "  • Stop bot:     ./stop.sh"
echo "  • Check status: ./status.sh"
echo "  • Restart bot:  ./restart.sh"
echo ""

# Create restart wrapper
cat > /tmp/metaverse_runner_$$.sh << 'EOF'
#!/bin/bash
MAX_RESTARTS=5
RESTART_COUNT=0
RESTART_DELAY=10

while [ $RESTART_COUNT -lt $MAX_RESTARTS ]; do
    echo "🚀 Starting bot (Attempt $((RESTART_COUNT + 1))/$MAX_RESTARTS)..."
    
    python3 main.py
    EXIT_CODE=$?
    
    if [ $EXIT_CODE -eq 0 ]; then
        echo "✅ Bot stopped gracefully"
        exit 0
    fi
    
    RESTART_COUNT=$((RESTART_COUNT + 1))
    
    if [ $RESTART_COUNT -lt $MAX_RESTARTS ]; then
        echo "⚠️  Bot crashed (exit code: $EXIT_CODE)"
        echo "⏳ Restarting in ${RESTART_DELAY} seconds..."
        sleep $RESTART_DELAY
    else
        echo "❌ Max restarts reached. Bot stopped."
        exit 1
    fi
done
EOF

chmod +x /tmp/metaverse_runner_$$.sh

# Start in screen or background
if command -v screen &> /dev/null; then
    screen -dmS metaverse bash -c "source venv/bin/activate && /tmp/metaverse_runner_$$.sh"
    echo -e "${GREEN}✅ Running in screen session 'metaverse'${NC}"
    echo -e "   Attach: ${CYAN}screen -r metaverse${NC}"
else
    nohup bash -c "source venv/bin/activate && /tmp/metaverse_runner_$$.sh" > logs/bot.log 2>&1 &
    echo $! > bot.pid
    echo -e "${GREEN}✅ Running with PID $(cat bot.pid)${NC}"
fi

echo ""
sleep 2

# Check if started successfully
if pgrep -f "python.*main.py" > /dev/null; then
    echo -e "${GREEN}🎉 Bot is running successfully!${NC}"
    echo ""
    echo "Monitor logs with:"
    echo -e "${CYAN}tail -f logs/bot.log${NC}"
else
    echo -e "${RED}❌ Failed to start bot${NC}"
    echo "Check logs:"
    tail -20 logs/bot.log
    exit 1
fi
